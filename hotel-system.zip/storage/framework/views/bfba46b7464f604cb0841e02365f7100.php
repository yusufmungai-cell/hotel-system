<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Receipt</title>

<style>
body{
    font-family: monospace;
    width: 280px;
    margin: auto;
    color:#000;
}

.center{text-align:center;}
.right{text-align:right;}
.bold{font-weight:bold;}
hr{border-top:1px dashed #000;margin:6px 0;}

@media print{
    body{width:280px;}
    button{display:none;}
}
</style>
</head>

<body>

<div class="center bold">YOUR RESTAURANT NAME</div>
<div class="center">Thank you for dining</div>
<hr>

<div>Order #: <?php echo e($order->id); ?></div>
<div>Waiter: <?php echo e($order->waiter->name ?? '-'); ?></div>
<div>Date: <?php echo e(now()->format('d/m/Y H:i')); ?></div>

<hr>

<?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="display:flex;justify-content:space-between;">
    <span><?php echo e($item->menuItem->name); ?> x<?php echo e($item->qty); ?></span>
    <span><?php echo e(number_format($item->total,2)); ?></span>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<hr>

<div style="display:flex;justify-content:space-between;" class="bold">
    <span>TOTAL</span>
    <span>KSh <?php echo e(number_format($order->total,2)); ?></span>
</div>

<div>Payment: <?php echo e(strtoupper($order->payment_method)); ?></div>

<hr>

<div class="center">**** SERVED ****</div>
<div class="center">Karibu Tena 😊</div>

<button onclick="window.print()">PRINT RECEIPT</button>

<script>
window.onload = () => setTimeout(()=>window.print(),500);
</script>
<script>
window.onload = function() {
    window.print();
};
</script>
<script>
window.onafterprint = function(){
    window.location.href = "<?php echo e(route('billing.index')); ?>";
};
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/billing/receipt.blade.php ENDPATH**/ ?>