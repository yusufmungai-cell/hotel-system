

<?php $__env->startSection('content'); ?>

<h1 class="text-3xl font-bold mb-6 text-center">READY FOR PICKUP</h1>

<?php if($orders->count()): ?>

<div class="grid grid-cols-3 gap-6">

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="bg-green-100 border-4 border-green-500 rounded-xl p-6 text-center shadow-lg">

    <div class="text-5xl font-bold mb-2">
        #<?php echo e($order->id); ?>

    </div>

    <div class="text-xl font-semibold mb-4">
        <?php echo e($order->waiter->name ?? 'Waiter'); ?>

    </div>

    <form method="POST" action="<?php echo e(route('pickup.collect',$order->id)); ?>">
        <?php echo csrf_field(); ?>
        <button class="bg-black text-white px-6 py-3 rounded-lg text-lg">
            COLLECT
        </button>
    </form>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php else: ?>

<div class="text-center text-2xl text-gray-400 mt-20">
No orders ready
</div>

<?php endif; ?>



<audio id="pickupSound">
    <source src="<?php echo e(asset('sounds/new-order.mp3')); ?>" type="audio/mpeg">
</audio>

<script>
let lastReady = <?php echo e($orders->max('id') ?? 0); ?>;

setInterval(()=>{
    fetch("<?php echo e(route('pickup.check')); ?>")
    .then(res=>res.json())
    .then(data=>{
        if(data.latest_id > lastReady){
            document.getElementById('pickupSound').play().catch(()=>{});
            location.reload();
        }
    });
},4000);
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/pickup/index.blade.php ENDPATH**/ ?>