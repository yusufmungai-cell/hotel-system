

<?php $__env->startSection('content'); ?>

<h1 class="text-2xl font-bold mb-6">Payroll Management</h1>

<?php if(session('success')): ?>
<div class="bg-green-100 text-green-700 p-3 rounded mb-4">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="bg-red-100 text-red-700 p-3 rounded mb-4">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>


<!-- GENERATE PAYROLL -->
<div class="bg-white shadow rounded p-6 mb-8">
    <h2 class="text-lg font-semibold mb-4">Generate Payroll</h2>

    <form method="POST" action="<?php echo e(route('payroll.generate')); ?>" class="flex gap-4 items-end">
        <?php echo csrf_field(); ?>

        <div>
            <label class="block text-sm font-medium">Select Month</label>
            <input type="month" name="month" required class="border p-2 rounded">
        </div>

        <button class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded shadow">
            Generate Payroll
        </button>
    </form>
</div>


<!-- PAYROLL HISTORY -->
<div class="bg-white shadow rounded p-6">

    <h2 class="text-lg font-semibold mb-4">Payroll History</h2>

    <table class="w-full border">
        <thead class="bg-gray-200">
            <tr>
                <th class="p-3 text-left">Employee</th>
                <th class="p-3 text-left">Month</th>
                <th class="p-3 text-left">Gross</th>
                <th class="p-3 text-left">Deductions</th>
                <th class="p-3 text-left">Net</th>
                <th class="p-3 text-left">Status</th>
                <th class="p-3 text-left">Payslip</th>
            </tr>
        </thead>

        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-t">

            <td class="p-3"><?php echo e($p->employee->name ?? '-'); ?></td>

            <td class="p-3">
                <?php echo e(\Carbon\Carbon::parse($p->payroll_month)->format('F Y')); ?>

            </td>

            <td class="p-3">KES <?php echo e(number_format($p->gross_pay,2)); ?></td>
            <td class="p-3">KES <?php echo e(number_format($p->deductions,2)); ?></td>
            <td class="p-3 font-bold">KES <?php echo e(number_format($p->net_pay,2)); ?></td>

            <!-- STATUS BADGE -->
            <td class="p-3">
                <?php
                    $month = \Carbon\Carbon::parse($p->payroll_month);
                    $attendanceMonth = \App\Models\AttendanceMonth::where('year',$month->year)
                        ->where('month',$month->month)
                        ->first();
                ?>

                <?php if(!$attendanceMonth): ?>
                    <span class="bg-gray-200 text-gray-800 px-3 py-1 rounded">Unknown</span>

                <?php elseif(!$attendanceMonth->status || $attendanceMonth->status == 'open'): ?>
                    <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded">Open</span>

                <?php elseif($attendanceMonth->status == 'approved' && !$attendanceMonth->payroll_posted): ?>
                    <span class="bg-green-100 text-green-800 px-3 py-1 rounded">Approved</span>

                <?php elseif($attendanceMonth->payroll_posted): ?>
                    <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded">Posted</span>
                <?php endif; ?>
            </td>

            <td class="p-3">
                <a href="/payroll/payslip/<?php echo e($p->id); ?>"
                   class="bg-gray-800 text-white px-3 py-1 rounded hover:bg-black">
                    PDF
                </a>
            </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7" class="p-4 text-center text-gray-500">
                No payroll generated yet
            </td>
        </tr>
        <?php endif; ?>
        </tbody>
    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/payroll/index.blade.php ENDPATH**/ ?>