

<?php $__env->startSection('content'); ?>

<a href="/employees/create" class="btn btn-primary">Add Employee</a>

<table class="table mt-4">
<tr>
<th>Staff No</th>
<th>Name</th>
<th>Department</th>
</tr>

<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($emp->staff_no); ?></td>
<td><?php echo e($emp->name); ?></td>
<td><?php echo e($emp->department); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/employees/index.blade.php ENDPATH**/ ?>