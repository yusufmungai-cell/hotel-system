

<?php $__env->startSection('content'); ?>

<h1 class="text-2xl font-bold mb-6">Employee Loans</h1>

<?php if(session('success')): ?>
<div class="bg-green-100 text-green-700 p-3 rounded mb-4">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<!-- ISSUE LOAN -->
<div class="bg-white p-5 rounded shadow mb-6">
    <form method="POST" action="<?php echo e(route('loans.store')); ?>" class="grid grid-cols-4 gap-4">
        <?php echo csrf_field(); ?>

        <select name="employee_id" class="border p-2 rounded" required>
            <option value="">Select Employee</option>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <input type="number" step="0.01" name="amount" placeholder="Loan Amount" class="border p-2 rounded" required>

        <input type="number" step="0.01" name="monthly_deduction" placeholder="Monthly Deduction" class="border p-2 rounded" required>

        <button class="bg-blue-600 text-white rounded px-4">
            Issue Loan
        </button>
    </form>
</div>

<!-- LOANS TABLE -->
<table class="w-full bg-white shadow rounded">
    <thead class="bg-gray-200">
        <tr>
            <th class="p-3 text-left">Employee</th>
            <th class="p-3">Amount</th>
            <th class="p-3">Balance</th>
            <th class="p-3">Monthly Deduction</th>
        </tr>
    </thead>

    <tbody>
    <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border-t">
            <td class="p-3"><?php echo e($loan->employee->name); ?></td>
            <td class="p-3"><?php echo e(number_format($loan->amount,2)); ?></td>
            <td class="p-3 font-bold"><?php echo e(number_format($loan->balance,2)); ?></td>
            <td class="p-3"><?php echo e(number_format($loan->monthly_deduction,2)); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/loans/index.blade.php ENDPATH**/ ?>