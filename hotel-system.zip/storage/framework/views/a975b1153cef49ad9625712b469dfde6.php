

<?php $__env->startSection('content'); ?>

<form method="POST" action="/employees">
<?php echo csrf_field(); ?>

<input name="staff_no" placeholder="Staff No" class="form-control mb-2">
<input name="name" placeholder="Name" class="form-control mb-2">
<label>Department</label>
<select name="department_id" class="border rounded p-2 w-full">
    <option value="">-- Select Department --</option>
    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<label>Position</label>
<select name="position_id" class="border rounded p-2 w-full">
    <option value="">-- Select Position --</option>
    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($pos->id); ?>"><?php echo e($pos->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<label>Employment Type</label>
<select name="employment_type_id" class="border rounded p-2 w-full" required>
    <?php $__currentLoopData = $employmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<input name="phone" placeholder="Phone" class="form-control mb-2">

<button class="btn btn-success">Save</button>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/employees/create.blade.php ENDPATH**/ ?>