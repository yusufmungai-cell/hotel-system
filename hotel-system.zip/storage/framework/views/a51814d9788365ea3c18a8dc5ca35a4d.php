

<?php $__env->startSection('content'); ?>

 <?php $__env->slot('header', null, []); ?> Suppliers <?php $__env->endSlot(); ?>

<?php if(session('success')): ?>
<div class="p-3 bg-green-100 text-green-700 mb-3">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<h3 class="mb-3">Add Supplier</h3>

<form method="POST">
<?php echo csrf_field(); ?>

<input name="name" placeholder="Supplier Name" class="border p-2 mb-2">
<input name="phone" placeholder="Phone" class="border p-2 mb-2">
<input name="email" placeholder="Email" class="border p-2 mb-2">

<button class="bg-blue-600 text-white px-4 py-2 rounded">
Add Supplier
</button>

</form>

<hr>

<h3>Existing Suppliers</h3>

<table class="w-full mt-3">
<tr>
<th>Name</th>
<th>Phone</th>
<th>Balance</th>
</tr>

<?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($s->name); ?></td>
<td><?php echo e($s->phone); ?></td>
<td><?php echo e($s->balance); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/suppliers/index.blade.php ENDPATH**/ ?>