

<?php $__env->startSection('content'); ?>

<table class="table w-full border mb-4">
<tr>
<th>Ingredient</th>
<th>Quantity</th>
</tr>

<?php $__currentLoopData = $request->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($item->ingredient->name); ?></td>
<td><?php echo e($item->qty); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<form method="POST" action="/storekeeper/approve/<?php echo e($request->id); ?>">
<?php echo csrf_field(); ?>
<button class="bg-green-600 text-white px-4 py-2">Approve & Deduct Stock</button>
</form>

<br>

<form method="POST" action="/storekeeper/reject/<?php echo e($request->id); ?>">
<?php echo csrf_field(); ?>
<button class="bg-red-600 text-white px-4 py-2">Reject Request</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/storekeeper/show.blade.php ENDPATH**/ ?>