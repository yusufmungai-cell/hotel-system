

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-6">Menu Items</h1>

<a href="<?php echo e(route('menu.create')); ?>"
   class="bg-blue-600 text-white px-4 py-2 rounded mb-4 inline-block">
   + Add Item
</a>

<table class="w-full bg-white shadow rounded">
    <thead class="bg-gray-100">
        <tr>
            <th class="p-3 text-left">Name</th>
            <th class="p-3">Price</th>
            <th class="p-3">Station</th>
            <th class="p-3">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border-t">
            <td class="p-3"><?php echo e($item->name); ?></td>
            <td class="p-3">KSh <?php echo e($item->price); ?></td>
            <td class="p-3 font-bold"><?php echo e(ucfirst($item->station)); ?></td>
            <td class="p-3">
                <a href="<?php echo e(route('menu.edit',$item->id)); ?>" class="text-blue-600">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/menu/index.blade.php ENDPATH**/ ?>