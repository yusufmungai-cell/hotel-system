

<?php $__env->startSection('content'); ?>

<h1 class="text-2xl font-bold mb-6">Confirm M-Pesa Payment</h1>

<div class="bg-white shadow rounded p-6 max-w-lg">

    <div class="mb-4">
        <div class="text-lg font-semibold">Order #<?php echo e($order->id); ?></div>
        <div class="text-gray-600">Amount: KSh <?php echo e(number_format($order->total,2)); ?></div>
    </div>

    <form method="POST" action="<?php echo e(route('billing.mpesa.confirm',$order->id)); ?>">
        <?php echo csrf_field(); ?>

        <label class="block mb-2 font-semibold">Enter M-Pesa Code</label>
        <input type="text" name="code" required
               class="w-full border rounded p-3 mb-4 text-lg uppercase">

        <button class="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded font-bold">
            Confirm Payment
        </button>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/billing/mpesa.blade.php ENDPATH**/ ?>