

<?php $__env->startSection('content'); ?>

<h1 class="text-2xl font-bold mb-6">Billing / Cashier</h1>

<?php if(session('success')): ?>
<div class="bg-green-100 text-green-700 p-3 rounded mb-4">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if($orders->count()): ?>

<div class="grid grid-cols-3 gap-6">

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="bg-white shadow rounded p-4">

    <div class="flex justify-between mb-2">
        <div class="font-bold text-lg">Order #<?php echo e($order->id); ?></div>
        <div class="text-sm text-gray-500"><?php echo e($order->waiter->name ?? 'N/A'); ?></div>
    </div>

    <hr class="mb-2">

    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="flex justify-between py-1">
        <span><?php echo e($item->menuItem->name); ?> x<?php echo e($item->qty); ?></span>
        <span>KSh <?php echo e(number_format($item->total,2)); ?></span>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <hr class="my-2">

    <div class="flex justify-between font-bold text-lg mb-3">
        <span>Total</span>
        <span>KSh <?php echo e(number_format($order->total,2)); ?></span>
    </div>

    <div class="grid grid-cols-3 gap-2">

    
   <form method="POST" action="<?php echo e(route('billing.pay',$order->id)); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="method" value="cash">
    <button type="submit"
        class="w-full h-12 rounded-lg font-semibold text-white
               bg-green-600 hover:bg-green-700
               flex items-center justify-center">
        CASH
    </button>
</form>


<form method="POST" action="<?php echo e(route('billing.pay',$order->id)); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="method" value="mpesa">
    <button type="submit"
        class="w-full h-12 rounded-lg font-semibold text-white
               bg-blue-600 hover:bg-blue-700
               flex items-center justify-center">
        M-PESA
    </button>
</form>


<form method="POST" action="<?php echo e(route('billing.pay',$order->id)); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="method" value="card">
    <button type="submit"
        class="w-full h-12 rounded-lg font-semibold text-white
               bg-gray-900 hover:bg-black border border-gray-700
               flex items-center justify-center">
        CARD
    </button>
</form>

</div>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php else: ?>

<div class="text-gray-400">No orders awaiting payment</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/billing/index.blade.php ENDPATH**/ ?>