

<?php $__env->startSection('content'); ?>

<h2 class="text-xl font-bold mb-4">
Payroll Preview — <?php echo e($month->format('F Y')); ?>

</h2>

<table border="1" cellpadding="6">
<tr>
    <th>Employee</th>
    <th>Days</th>
    <th>Gross</th>
    <th>Deductions</th>
    <th>Net Pay</th>
</tr>

<?php $__currentLoopData = $preview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($row['employee']); ?></td>
    <td><?php echo e($row['days']); ?></td>
    <td><?php echo e(number_format($row['gross'],2)); ?></td>
    <td><?php echo e(number_format($row['deductions'],2)); ?></td>
    <td><b><?php echo e(number_format($row['net'],2)); ?></b></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<br>

<hr class="my-4">

<form method="POST" action="<?php echo e(route('payroll.post')); ?>">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="month" value="<?php echo e($month->format('Y-m')); ?>">

    <button class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded font-bold">
        POST PAYROLL
    </button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/payroll/preview.blade.php ENDPATH**/ ?>