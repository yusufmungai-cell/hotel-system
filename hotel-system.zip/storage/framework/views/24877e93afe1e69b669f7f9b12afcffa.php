

<?php $__env->startSection('content'); ?>
<h2>Attendance Monthly Approval</h2>
<?php if(session('success')): ?>
<div class="bg-green-200 text-green-900 p-3 rounded mb-4">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="bg-red-200 text-red-900 p-3 rounded mb-4">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<form method="GET">
    <input type="month" name="month" value="<?php echo e($month->format('Y-m')); ?>">
    <button>Load</button>
</form>

<hr>

<form method="POST" action="<?php echo e(route('attendance.approval.update')); ?>">
<?php echo csrf_field(); ?>

<table border="1" cellpadding="6">
<tr>
    <th>Employee</th>
    <th>Date</th>
    <th>Status</th>
    <th>Overtime</th>
</tr>

<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $employee->attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr> <td><?php echo e($employee->name); ?></td> <td><?php echo e($att->date); ?></td>

```
    <td>
        <select name="attendance[<?php echo e($att->id); ?>][status]">
            <option value="present" <?php echo e($att->status=='present'?'selected':''); ?>>Present</option>
            <option value="halfday" <?php echo e($att->status=='halfday'?'selected':''); ?>>Half Day</option>
            <option value="absent" <?php echo e($att->status=='absent'?'selected':''); ?>>Absent</option>
            <option value="offday" <?php echo e($att->status=='offday'?'selected':''); ?>>Off Day</option>
            <option value="duty" <?php echo e($att->status=='duty'?'selected':''); ?>>Official Duty</option>
        </select>
    </td>

    <td>
        <input type="number" step="0.1" name="attendance[<?php echo e($att->id); ?>][overtime_hours]" value="<?php echo e($att->overtime_hours); ?>">
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
```

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<br>
<button type="submit">Save Changes</button>
</form>

<hr>
<h2 class="text-xl font-bold mt-6 mb-2">Monthly Summary</h2>

<table border="1" cellpadding="6" class="mb-6">
<tr>
    <th>Employee</th>
    <th>Present</th>
    <th>Half Day</th>
    <th>Absent</th>
    <th>Duty</th>
    <th>Off Day</th>
    <th>Overtime Hrs</th>
</tr>

<?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($row['employee']); ?></td>
    <td><?php echo e($row['present']); ?></td>
    <td><?php echo e($row['halfday']); ?></td>
    <td><?php echo e($row['absent']); ?></td>
    <td><?php echo e($row['duty']); ?></td>
    <td><?php echo e($row['offday']); ?></td>
    <td><?php echo e($row['overtime']); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<div style="background:#ffe9b3;padding:12px;margin-bottom:10px;">
<b>Important:</b> Once approved:
<ul>
<li>Attendance will be locked</li>
<li>Payroll will use this data</li>
<li>No further edits allowed</li>
</ul>
</div>

<form method="POST" action="<?php echo e(route('attendance.approval.approve')); ?>">
<?php echo csrf_field(); ?>
<input type="hidden" name="month" value="<?php echo e($month->format('Y-m')); ?>">
<button type="submit">APPROVE ENTIRE MONTH</button>
<a href="<?php echo e(route('payroll.preview',['month'=>$month->format('Y-m')])); ?>"
style="background:blue;color:white;padding:10px;display:inline-block;margin-top:10px;">
Preview Payroll
</a>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/attendance/approval.blade.php ENDPATH**/ ?>