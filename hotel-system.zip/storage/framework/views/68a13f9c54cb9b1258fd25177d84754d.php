

<?php $__env->startSection('content'); ?>

<h1 class="text-2xl font-bold mb-4">Ingredients</h1>

<?php if(session('success')): ?>
<div class="p-3 bg-green-100 text-green-700 mb-4 rounded">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="bg-white p-4 rounded shadow mb-6">
    <form method="POST">
        <?php echo csrf_field(); ?>

        <div class="grid grid-cols-3 gap-3">
            <input name="name" placeholder="Ingredient Name"
                class="border p-2 rounded">

            <input name="unit" placeholder="Unit (kg, pcs, litre)"
                class="border p-2 rounded">

            <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                Add Ingredient
            </button>
        </div>
    </form>
</div>

<div class="bg-white rounded shadow">
    <table class="w-full">
        <thead class="bg-gray-100">
            <tr class="text-left">
                <th class="p-3">Name</th>
                <th class="p-3">Unit</th>
                <th class="p-3">Stock</th>
            </tr>
        </thead>

        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-t">
                <td class="p-3"><?php echo e($i->name); ?></td>
                <td class="p-3"><?php echo e($i->unit); ?></td>
                <td class="p-3 font-semibold"><?php echo e($i->stock); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="p-4 text-center text-gray-400">
                    No ingredients added yet
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/ingredients/index.blade.php ENDPATH**/ ?>