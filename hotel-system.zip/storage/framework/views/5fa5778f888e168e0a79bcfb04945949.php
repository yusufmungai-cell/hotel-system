

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="p-3 bg-green-100 text-green-700 mb-3">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<h3 class="mb-3">Check In Guest</h3>

<form method="POST" action="/bookings/checkin">
<?php echo csrf_field(); ?>

<input name="name" placeholder="Guest Name" class="border p-2 mb-2">
<input name="phone" placeholder="Phone" class="border p-2 mb-2">

<select name="room_id" class="border p-2 mb-2">
<?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($r->id); ?>">
Room <?php echo e($r->room_number); ?> - <?php echo e($r->type->name); ?>

</option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<button class="bg-blue-600 text-white px-4 py-2 rounded">
Check In
</button>

</form>

<hr>

<h3>Current Bookings</h3>

<table class="w-full mt-3">
<tr>
<th>Guest</th>
<th>Room</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($b->guest->name); ?></td>
<td><?php echo e($b->room->room_number); ?></td>
<td><?php echo e($b->status); ?></td>

<td>
<?php if($b->status == 'checked_in'): ?>
<a href="/bookings/checkout/<?php echo e($b->id); ?>" class="text-red-600">
Checkout
</a>
<?php endif; ?>
</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/bookings/index.blade.php ENDPATH**/ ?>