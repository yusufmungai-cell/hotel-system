

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="bg-green-100 p-3 mb-4"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table w-full border">
<tr>
<th>ID</th>
<th>Date</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($req->id); ?></td>
<td><?php echo e($req->created_at); ?></td>
<td><?php echo e($req->status); ?></td>
<td>
<a href="/storekeeper/request/<?php echo e($req->id); ?>" class="btn btn-primary">Open</a>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/storekeeper/index.blade.php ENDPATH**/ ?>