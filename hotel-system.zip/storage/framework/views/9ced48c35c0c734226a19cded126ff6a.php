

<?php $__env->startSection('content'); ?>
<div class="flex h-[85vh] gap-4">

    
    <div class="w-2/3 bg-white rounded shadow p-4 overflow-y-auto">
        <h2 class="text-xl font-bold mb-4">Menu</h2>

        <div class="grid grid-cols-4 gap-4">

            <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="POST" action="<?php echo e(route('orders.addItem', $order->id)); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="menu_item_id" value="<?php echo e($item->id); ?>">
                <input type="hidden" name="qty" value="1">

                <button class="border rounded-lg p-3 hover:bg-green-50 w-full h-36 flex flex-col items-center justify-center">

                    
                    <?php if($item->image): ?>
                        <img src="<?php echo e(asset('storage/'.$item->image)); ?>" class="h-16 mb-2 object-cover">
                    <?php else: ?>
                        <div class="h-16 w-16 bg-gray-200 rounded mb-2 flex items-center justify-center text-2xl">
                            🍽️
                        </div>
                    <?php endif; ?>

                    <span class="font-semibold text-sm text-center"><?php echo e($item->name); ?></span>
                    <span class="text-green-600 font-bold">KSh <?php echo e(number_format($item->price,2)); ?></span>

                </button>
            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>


    
    <div class="w-1/3 bg-white rounded shadow p-4 flex flex-col">
        <h2 class="text-xl font-bold mb-4">Current Order #<?php echo e($order->order_no); ?></h2>

        <div id="orderItems" class="flex-1 overflow-y-auto">

            <?php $__empty_1 = true; $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<div class="flex justify-between items-center border-b py-3 text-lg">

    
    <div class="flex-1">
        <div class="font-semibold">
            <?php echo e($row->menuItem->name); ?>

        </div>

        <div class="text-sm text-gray-500">
            KSh <?php echo e(number_format($row->price,2)); ?>

        </div>
    </div>


    
    <div class="flex items-center gap-3">

    
    <form method="POST" action="<?php echo e(route('orders.decrease', [$order->id,$row->id])); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit"
            style="background:#dc2626;color:white;width:44px;height:44px;font-size:24px;font-weight:bold;border-radius:12px;box-shadow:0 3px 8px rgba(0,0,0,.35)">
            −
        </button>
    </form>

    
    <span style="font-size:22px;font-weight:bold;width:40px;text-align:center;">
        <?php echo e($row->qty); ?>

    </span>

    
    <form method="POST" action="<?php echo e(route('orders.increase', [$order->id,$row->id])); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit"
            style="background:#16a34a;color:white;width:44px;height:44px;font-size:24px;font-weight:bold;border-radius:12px;box-shadow:0 3px 8px rgba(0,0,0,.35)">
            +
        </button>
    </form>

</div>
    
    <div class="w-24 text-right font-semibold">
        KSh <?php echo e(number_format($row->total,2)); ?>

    </div>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="text-gray-400 text-center mt-10">
    No items added yet
</div>
<?php endif; ?>

        </div>

        <div class="border-t pt-4">
            <div class="flex justify-between font-bold text-lg mb-4">
                <span>Total</span>
                <span id="orderTotal">KSh <?php echo e(number_format($order->total,2)); ?></span>
            </div>

            <form method="POST" action="<?php echo e(route('orders.close', $order->id)); ?>">
                <?php echo csrf_field(); ?>
                <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded text-lg">
                    Send to Kitchen
                </button>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<audio id="pickupSound">
    <source src="<?php echo e(asset('sounds/ready.mp3')); ?>" type="audio/mpeg">
</audio>

<script>
let lastReady = 0;

setInterval(() => {

    fetch("<?php echo e(route('kitchen.checkReady')); ?>")
    .then(res => res.json())
    .then(data => {

        if(data.ready_id > lastReady){

            lastReady = data.ready_id;

            document.getElementById('pickupSound').play();

            alert("ORDER READY FOR PICKUP!");

        }

    });

},3000);
</script>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/pos/show.blade.php ENDPATH**/ ?>