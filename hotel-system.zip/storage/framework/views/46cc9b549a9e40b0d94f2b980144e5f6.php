

<?php $__env->startSection('content'); ?>

<h1 class="text-2xl font-bold mb-6">Kitchen Display</h1>

<?php if($orders->count()): ?>

<div class="grid grid-cols-3 gap-6">

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
$minutes = $order->created_at->timezone(config('app.timezone'))->diffInMinutes(now());

$color = 'bg-green-100 border-green-400';
if($minutes >= 5)  $color = 'bg-yellow-100 border-yellow-400';
if($minutes >= 15) $color = 'bg-orange-100 border-orange-500';
if($minutes >= 30) $color = 'bg-red-200 border-red-600';
?>

<div class="border-l-8 <?php echo e($color); ?> rounded p-4 shadow">

    <div class="flex justify-between items-center">
        <div>
    <div class="text-2xl font-bold">
        Order #<?php echo e($order->id); ?>

    </div>

    <div class="text-sm text-blue-700 font-semibold">
        Waiter: <?php echo e($order->waiter->name ?? 'Unknown'); ?>

    </div>
</div>
<div class="text-sm text-blue-700 font-semibold">
    <?php echo e($order->waiter->name ?? 'Unknown waiter'); ?>

</div>
        <div class="text-right">
            <div class="text-sm text-gray-600">
                <?php echo e($order->created_at->timezone(config('app.timezone'))->format('H:i')); ?>

            </div>
            <div class="font-bold">
                <?php echo e($minutes); ?> min
            </div>
        </div>
    </div>

    <hr class="my-2">

    
    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex justify-between text-lg py-1">
            <span><?php echo e($item->menuItem->name); ?></span>
            <span class="font-bold">x<?php echo e($item->qty); ?></span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<form method="POST" action="<?php echo e(route('kitchen.ready',$order->id)); ?>" class="mt-4">
    <?php echo csrf_field(); ?>
    <button class="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded text-lg font-bold">
        KITCHEN READY
    </button>
</form>
   


</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php else: ?>

<div class="text-gray-400 text-lg">No orders in kitchen</div>

<?php endif; ?>



<audio id="newOrderSound">
    <source src="<?php echo e(asset('sounds/new-order.mp3')); ?>" type="audio/mpeg">
</audio>

<script>
let kitchenOpenedAt = new Date().toISOString();

setInterval(() => {

    fetch("<?php echo e(route('kitchen.check')); ?>?since=" + kitchenOpenedAt)
        .then(res => res.json())
        .then(data => {

            if(data.new_orders > 0){

                // PLAY SOUND
                const audio = document.getElementById('newOrderSound');
                audio.currentTime = 0;
                audio.play().catch(()=>{});

                // POPUP FLASH
                document.body.classList.add('bg-red-300');
                setTimeout(()=>document.body.classList.remove('bg-red-300'),1000);

                // RELOAD ORDERS
                setTimeout(()=>location.reload(),1200);
            }

        });

}, 5000);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/kitchen/index.blade.php ENDPATH**/ ?>