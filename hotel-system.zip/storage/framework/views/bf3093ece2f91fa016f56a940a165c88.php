

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="p-3 bg-green-100 text-green-700 mb-3">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<h3 class="mb-3">Receive Goods</h3>

<form method="POST">
<?php echo csrf_field(); ?>

<select name="supplier_id" class="border p-2 mb-2">
<?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<input name="reference" placeholder="Reference No" class="border p-2 mb-2">

<select name="ingredient_id" class="border p-2 mb-2 w-full">
    <option value="">Select Ingredient</option>
    <?php $__currentLoopData = \App\Models\Ingredient::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($ingredient->id); ?>">
            <?php echo e($ingredient->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<input name="qty" placeholder="Quantity" class="border p-2 mb-2">
<input name="price" placeholder="Unit Price" class="border p-2 mb-2">

<button class="bg-blue-600 text-white px-4 py-2 rounded">
Receive Items
</button>

</form>

<hr class="my-4">

<h3>Receiving History</h3>

<?php $__currentLoopData = $receivings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="border p-3 mb-3">

<strong>Supplier:</strong> <?php echo e($r->supplier->name); ?> <br>
<strong>Total:</strong> <?php echo e($r->total); ?> <br>
<strong>Date:</strong> <?php echo e($r->created_at); ?> <br>

<table class="w-full mt-2 border">
<tr class="bg-gray-100">
<th class="p-2">Item</th>
<th class="p-2">Qty</th>
<th class="p-2">Price</th>
<th class="p-2">Total</th>
</tr>

<?php $__currentLoopData = $r->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td class="p-2"><?php echo e($i->ingredient->name ?? ''); ?></td>
<td class="p-2"><?php echo e($i->qty); ?></td>
<td class="p-2"><?php echo e($i->price); ?></td>
<td class="p-2"><?php echo e($i->total); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/receivings/index.blade.php ENDPATH**/ ?>