

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="p-3 bg-green-100 text-green-700 mb-3">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<h3>Request Items from Store</h3>

<form method="POST">
<?php echo csrf_field(); ?>

<select name="ingredient_id" class="border p-2 mb-2" required>
    <option value="">-- Select Ingredient --</option>

    <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($i->id); ?>"><?php echo e($i->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<input name="qty" placeholder="Quantity (numbers only)" 
       class="border p-2 mb-2" required type="number">

<button class="bg-blue-600 text-white px-4 py-2 rounded">
Request Item
</button>

</form>


<hr>

<h3>Request History</h3>

<h3 class="text-lg font-bold mt-6 mb-2">Request History</h3>

<table class="w-full border">
    <tr class="bg-gray-100">
        <th class="p-2 text-left">ID</th>
        <th class="p-2 text-left">Requested Items</th>
        <th class="p-2 text-left">Status</th>
        <th class="p-2 text-left">Date</th>
    </tr>

    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="border-b">
        <td class="p-2"><?php echo e($req->id); ?></td>

        <td class="p-2">
            <?php $__currentLoopData = $req->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                - <?php echo e($item->ingredient->name ?? 'Unknown'); ?> : <?php echo e($item->qty); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>

        <td class="p-2"><?php echo e($req->status); ?></td>

        <td class="p-2"><?php echo e($req->created_at); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php if($requests->where('status','pending')->first()): ?>
<form method="POST" action="/production/submit">
    <?php echo csrf_field(); ?>
    <button class="bg-green-600 text-white px-4 py-2 rounded mt-3">
        Submit Current Request to Store
    </button>
</form>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-system\resources\views/production/index.blade.php ENDPATH**/ ?>