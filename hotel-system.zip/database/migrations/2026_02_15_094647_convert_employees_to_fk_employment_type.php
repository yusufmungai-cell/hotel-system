<?php

use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        // Already handled in previous migration
    }

    public function down(): void
    {
        //
    }
};
